import React, { useEffect, useState, useRef } from "react";
import { View, Text, FlatList, StyleSheet, Image, TouchableOpacity, Linking, Alert, ActivityIndicator, Animated, Dimensions } from "react-native";

export default function NewsPage() {
  const [articles, setArticles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);
  const screenWidth = Dimensions.get('window').width;

  // Animação do texto
  const scrollX = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const fetchNews = async () => {
      try {
        const response = await fetch(
          "https://newsapi.org/v2/top-headlines?country=br&apiKey=5dbe2f5b417b48edbed7690ea03878d2"
        );
        const data = await response.json();
        if (data.articles) {
          setArticles(data.articles);
        } else {
          throw new Error("Erro ao carregar notícias");
        }
      } catch (error) {
        setError(true);
        Alert.alert("Erro", "Não foi possível carregar as notícias.");
      } finally {
        setLoading(false);
      }
    };

    fetchNews();
    
    
    Animated.loop(
      Animated.sequence([
        Animated.timing(scrollX, {
          toValue: screenWidth - 200, 
          duration: 5000,
          useNativeDriver: true,
        }),
        Animated.timing(scrollX, {
          toValue: 0,
          duration: 5000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  const openLink = (url) => {
    Linking.openURL(url).catch(() => {
      Alert.alert("Erro", "Não foi possível abrir o link.");
    });
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#ffffff" />
        <Text style={styles.loadingText}>Carregando notícias...</Text>
      </View>
    );
  }

  if (error) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.errorText}>Erro ao carregar notícias.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      {/* Texto animado no topo */}
      <View style={styles.marqueeContainer}>
        <Animated.Text
          style={[
            styles.marqueeText,
            {
              transform: [{ translateX: scrollX }],
            },
          ]}
        >
          Notícias 24 horas, todo momento!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
          noticias integrado;
        </Animated.Text>
      </View>
      
      <FlatList
        data={articles}
        numColumns={2}
        keyExtractor={(item, index) => index.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.articleContainer}
            onPress={() => openLink(item.url)}
            activeOpacity={0.9}
          >
            {item.urlToImage && (
              <Image source={{ uri: item.urlToImage }} style={styles.image} />
            )}
            <View style={styles.articleContent}>
              <Text style={styles.headline}>{item.title}</Text>
              <Text style={styles.description}>
                {item.description || "Leia mais..."}
              </Text>
            </View>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#1e3a8a",
    padding: 15,
  },
  marqueeContainer: {
    height: 40,
    overflow: 'hidden',
    backgroundColor: "#ffffff",
    justifyContent: "center",
    marginBottom: 20,
  },
  marqueeText: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#1e3a8a",
    paddingHorizontal: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1e3a8a",
  },
  loadingText: {
    color: "#ffffff",
    marginTop: 10,
  },
  errorText: {
    color: "#ff4c4c",
    fontSize: 18,
    fontWeight: "bold",
  },
  articleContainer: {
    flex: 1,
    backgroundColor: "#ffffff",
    margin: 10,
    borderRadius: 15,
    overflow: "hidden",
    shadowColor: "#000",
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 4 },
    shadowRadius: 5,
    elevation: 6,
    borderColor: "#4e54c8",
    borderWidth: 1,
  },
  image: {
    width: "100%",
    height: 150,
    borderTopLeftRadius: 15,
    borderTopRightRadius: 15,
  },
  articleContent: {
    padding: 15,
  },
  headline: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1e3a8a",
    marginBottom: 10,
  },
  description: {
    fontSize: 14,
    color: "#555",
  },
});
